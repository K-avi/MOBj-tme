# Laïla Lahkim Bennani 21102544 Ivan Mulot-Radojcic 21102722

# TME 2 : 

## Question 1) 

cf fichiers Box.cpp, Box.hpp, Main.cpp

## Question 2) 

Si on met les constructeurs en private dans la classe, on obtiendra des erreurs à la compilation. Car on ne peut pourra 
plus instancier d'objets box. 
     
   
